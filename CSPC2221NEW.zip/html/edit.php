<!DOCTYPE html>
<html>
<head>
	<title>Update Player - TicTacToe Platform</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
	<h1 class="mb-4">TicTacToe Platform - Edit Achievements</h1>
	<?php
		$servername = "localhost";
		$username   = "root";
		$password   = "root";
		$database   = "tictactoe";
		
		$conn = new mysqli($servername, $username, $password, $database);
		
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} else {
			echo "<div class='container mt-4'>";
		}
		
		$query = "SELECT AchievementID, Title, Description FROM Achievement ORDER BY AchievementID";
		$result = $conn->query($query);
		
		echo "<h2>All Achievements</h2>";
		
		if ($result->num_rows > 0) {
			echo "<table class='table table-bordered table-striped mt-3'>";
			echo "<tr><th>AchievementID</th><th>Title</th><th>Description</th></tr>";
			while ($row = $result->fetch_assoc()) {
				echo "<tr>
					<td>" . $row["AchievementID"] . "</td>
					<td>" . $row["Title"] . "</td>
					<td>" . $row["Description"] . "</td>
				</tr>";
			}
			echo "</table>";
		} else {
			echo "No achievements found.";
		}
		
		$conn->close();
		
		echo "</div></br>";
		?>
		<?php
		$servername = "localhost";
		$username   = "root";
		$password   = "root";
		$database   = "tictactoe";
		
		$conn = new mysqli($servername, $username, $password, $database);
		
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}else{
			echo "<div class='container mt-4'>";
		}
		
		$query = "SELECT gu.Username, a.Title, aw.AwardDate
				FROM Awarded aw
				JOIN GameUser gu ON aw.UserID = gu.UserID
				JOIN Achievement a ON aw.AchievementID = a.AchievementID
				ORDER BY aw.AwardDate DESC";
		$result = $conn->query($query);
		
		echo "<h2>All Awarded Achievements</h2>";
		
		if ($result->num_rows > 0) {
			echo "<table class='table table-bordered table-striped mt-3'>";
			echo "<tr><th>Username</th><th>Achievement</th><th>Date Awarded</th></tr>";
			while ($row = $result->fetch_assoc()) {
				echo "<tr>
					<td>" . $row["Username"] . "</td>
					<td>" . $row["Title"] . "</td>
					<td>" . $row["AwardDate"] . "</td>
				</tr>";
			}
			echo "</table>";
		} else {
			echo "No awarded achievements found.";
		}
		
		$conn->close();
		
		echo "</div></br>";

	?>
	<?php
	$servername = "localhost";
	$username   = "root";
	$password   = "root";
	$database   = "tictactoe";
	
	$conn = new mysqli($servername, $username, $password, $database);
	
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} else {
		echo "<div class='container mt-4'>";
	}
	
	$query = "SELECT a.Name AS AdminName, ac.Title AS Achievement, e.EditDate
			FROM Edits e
			JOIN Admin a ON e.AdminID = a.AdminID
			JOIN Achievement ac ON e.AchievementID = ac.AchievementID
			ORDER BY e.EditDate DESC";
	$result = $conn->query($query);
	
	echo "<h2>All Achievement Edits</h2>";
	
	if ($result->num_rows > 0) {
		echo "<table class='table table-bordered table-striped mt-3'>";
		echo "<tr><th>Admin Name</th><th>Achievement Edited</th><th>Edit Date</th></tr>";
		while ($row = $result->fetch_assoc()) {
			echo "<tr>
				<td>" . $row["AdminName"] . "</td>
				<td>" . $row["Achievement"] . "</td>
				<td>" . $row["EditDate"] . "</td>
			</tr>";
		}
		echo "</table>";
	} else {
		echo "No edits found.";
	}
	
	$conn->close();
	
	echo "</div><br>";
	?>


	<div class="card" style="max-width: 500px;">
		<div class="card-header bg-danger text-white"><h5 class="mb-0">Update Achievement</h5></div>
		<div class="card-body">
			<form action="updateAchievements.php" method="post">
				<div class="mb-3">
					<label class="form-label">Achievement ID</label>
					<input type="number" name="AchievementID" class="form-control" placeholder="e.g. 3">
				</div>
				<div class="mb-3">
					<label class="form-label">New Title</label>
					<input type="text" name="Title" class="form-control" placeholder="e.g. Veteran">
				</div>
				<div class="mb-3">
					<label class="form-label">New Description</label>
					<input type="text" name="Description" class="form-control" placeholder="e.g. Play 10 matches">
				</div>
				<button type="submit" class="btn btn-danger w-100">Update Achievement</button>
			</form>
		</div>
	</div>
	<div class="container mt-4">
	<div class="card" style="max-width: 500px;">
		<div class="card-header bg-success text-white"><h5 class="mb-0">New Achievement Registration</h5></div>
		<div class="card-body">
			<form action="addAchievements.php" method="post">
				<div class="mb-3">
					<label class="form-label">Achievement ID</label>
					<input type="number" name="AchievementID" class="form-control" placeholder="e.g. 14">
				</div>
				<div class="mb-3">
					<label class="form-label">Title</label>
					<input type="text" name="Title" class="form-control" placeholder="e.g. Veteran2">
				</div>
				<div class="mb-3">
					<label class="form-label">Description</label>
					<input type="text" name="Description" class="form-control" placeholder="e.g. Play 50 matches">
				</div>
				<button type="submit" class="btn btn-primary w-100">Add</button>
			</form>
	</div>
	<div class="card" style="max-width: 500px;">
	<div class="card-header bg-danger text-white"><h5 class="mb-0">Delete Achievement (Cascade)</h5></div>
	<div class="card-body">
		<div class="alert alert-warning">
			Warning: Deleting an archivement will also delete all related records due to cascade delete.
		</div>
		<form action="deleteAchievements.php" method="post">
			<div class="mb-3">
				<label class="form-label">Achievement ID to Delete</label>
				<input type="number" name="AchievementID" class="form-control" placeholder="e.g. 1">
			</div>
			<button type="submit" class="btn btn-danger w-100">Delete Achievement</button>
		</form>
	</div>
	</div>
	<br><a href="admin.html" class="btn btn-secondary mt-2">Back to Main Menu</a>
</div>
</body>
</html>
