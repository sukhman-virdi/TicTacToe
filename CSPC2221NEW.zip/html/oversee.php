<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$servername = "localhost";
$username   = "root";
$password   = "root";
$database   = "tictactoe";
 
// Create connection
$conn = new mysqli($servername, $username, $password, $database);
 
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} else {
	echo "<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'>";
	echo "<div class='container mt-4'>";
	echo "Connection Successful! <br>";
}
 
// --- Aggregation Query 1: MIN, MAX, AVG Ranking Points ---
echo "<h2>Aggregation Query - Ranking Points Stats</h2>";
echo "<b>Query: </b> SELECT MIN, MAX, AVG of RankingPoints FROM Player <br><br>";
 
$query1 = "SELECT MIN(RankingPoints) AS MinPoints,
                  MAX(RankingPoints) AS MaxPoints,
                  AVG(RankingPoints) AS AvgPoints
           FROM Player";
 
$result1 = $conn->query($query1);
 
if ($result1->num_rows > 0) {
	echo "<table class='table table-bordered table-striped mt-3'>";
	echo "<tr><th>Minimum Ranking Points</th><th>Maximum Ranking Points</th><th>Average Ranking Points</th></tr>";
	$row = $result1->fetch_assoc();
	echo "<tr>
		<td>" . $row["MinPoints"] . "</td>
		<td>" . $row["MaxPoints"] . "</td>
		<td>" . round($row["AvgPoints"], 2) . "</td>
	</tr>";
	echo "</table>";
} else {
	echo "0 results";
}
 
// Show overall average for reference
$avgQuery  = "SELECT AVG(RankingPoints) AS OverallAvg FROM Player";
$avgResult = $conn->query($avgQuery);
$avgRow    = $avgResult->fetch_assoc();
$overallAvg = round($avgRow["OverallAvg"], 2);
 
// Nested aggregation with GROUP BY
// Find difficulty levels where average player ranking is above the overall average
$query = "SELECT pm.Difficulty, AVG(p.RankingPoints) AS AvgRanking
          FROM Player p
          JOIN Joins j ON p.PlayerID = j.PlayerID
          JOIN Tournament_Managed tm ON j.TournamentID = tm.TournamentID
          JOIN PrizeMoney pm ON tm.Difficulty = pm.Difficulty
          GROUP BY pm.Difficulty
          HAVING AVG(p.RankingPoints) > (
               SELECT AVG(RankingPoints) FROM Player
          )";
 
echo "<h2>Nested Aggregation Query Result</h2>";
echo "<b>Query: </b> Find difficulty levels where average player ranking is above the overall average <br><br>";
echo "<b>Overall Average Ranking Points: </b>" . $overallAvg . "<br><br>";
 
$result = $conn->query($query);
 
if ($result->num_rows > 0) {
	echo "<table class='table table-bordered table-striped mt-3'>";
	echo "<tr><th>Difficulty Level</th><th>Average Ranking Points</th></tr>";
	while ($row = $result->fetch_assoc()) {
		echo "<tr>
			<td>" . $row["Difficulty"] . "</td>
			<td>" . round($row["AvgRanking"], 2) . "</td>
		</tr>";
	}
	echo "</table>";
} else {
	echo "No difficulty levels are above the overall average.";
}
 
$query = "SELECT a.AdminID, a.Name, a.Email, a.Password, a.Level, d.Department
          FROM Admin a
          JOIN Department d ON a.Level = d.Level
          ORDER BY a.AdminID";
$result = $conn->query($query);
 
echo "<h2>All Admins</h2>";
 
if ($result->num_rows > 0) {
	echo "<table class='table table-bordered table-striped mt-3'>";
	echo "<tr><th>AdminID</th><th>Name</th><th>Email</th><th>Password</th><th>Level</th><th>Department</th></tr>";
	while ($row = $result->fetch_assoc()) {
		echo "<tr>
			<td>" . $row["AdminID"] . "</td>
			<td>" . $row["Name"] . "</td>
			<td>" . $row["Email"] . "</td>
			<td>" . $row["Password"] . "</td>
			<td>" . $row["Level"] . "</td>
			<td>" . $row["Department"] . "</td>
		</tr>";
	}
	echo "</table>";
} else {
	echo "No admins found.";
}

$query = "SELECT Level, Department FROM Department ORDER BY Level";
$result = $conn->query($query);
 
echo "<h2>All Departments</h2>";
 
if ($result->num_rows > 0) {
	echo "<table class='table table-bordered table-striped mt-3'>";
	echo "<tr><th>Level</th><th>Department</th></tr>";
	while ($row = $result->fetch_assoc()) {
		echo "<tr>
			<td>" . $row["Level"] . "</td>
			<td>" . $row["Department"] . "</td>
		</tr>";
	}
	echo "</table>";
} else {
	echo "No departments found.";
}
 
$query = "SELECT p.PlayerID, gu.Username, p.TotalWins, p.TotalLosses, p.TotalDraws, p.RankingPoints
          FROM Player p
          JOIN GameUser gu ON p.PlayerID = gu.UserID
          ORDER BY p.RankingPoints DESC";
$result = $conn->query($query);
echo "<h2>All Players</h2>";
 
if ($result->num_rows > 0) {
	echo "<table class='table table-bordered table-striped mt-3'>";
	echo "<tr><th>PlayerID</th><th>Username</th><th>TotalWins</th><th>TotalLosses</th><th>TotalDraws</th><th>RankingPoints</th></tr>";
	while ($row = $result->fetch_assoc()) {
		echo "<tr>
			<td>" . $row["PlayerID"] . "</td>
			<td>" . $row["Username"] . "</td>
			<td>" . $row["TotalWins"] . "</td>
			<td>" . $row["TotalLosses"] . "</td>
			<td>" . $row["TotalDraws"] . "</td>
			<td>" . $row["RankingPoints"] . "</td>
		</tr>";
	}
	echo "</table>";
} else {
	echo "No players found.";
}

$query = "SELECT UserID, Username, Email, Password FROM GameUser";
$result = $conn->query($query);
 
echo "<h2>All Users</h2>";
 
if ($result->num_rows > 0) {
	echo "<table class='table table-bordered table-striped mt-3'>";
	echo "<tr><th>UserID</th><th>Username</th><th>Email</th><th>Password</th></tr>";
	while ($row = $result->fetch_assoc()) {
		echo "<tr>
			<td>" . $row["UserID"] . "</td>
			<td>" . $row["Username"] . "</td>
			<td>" . $row["Email"] . "</td>
			<td>" . $row["Password"] . "</td>
		</tr>";
	}
	echo "</table>";
} else {
	echo "No users found.";
}

$query = "SELECT a.Name AS AdminName, gu.Username, o.Admin_Comments
          FROM Oversees o
          JOIN Admin a ON o.AdminID = a.AdminID
          JOIN GameUser gu ON o.UserID = gu.UserID
          ORDER BY a.Name";
$result = $conn->query($query);
 
echo "<h2>All Oversees Records</h2>";
 
if ($result->num_rows > 0) {
	echo "<table class='table table-bordered table-striped mt-3'>";
	echo "<tr><th>Admin Name</th><th>Username</th><th>Admin Comments</th></tr>";
	while ($row = $result->fetch_assoc()) {
		echo "<tr>
			<td>" . $row["AdminName"] . "</td>
			<td>" . $row["Username"] . "</td>
			<td>" . $row["Admin_Comments"] . "</td>
		</tr>";
	}
	echo "</table>";
} else {
	echo "No oversees records found.";
}

$conn->close();
 
echo "</div><br><a class='btn btn-secondary' href='admin.html'>Main Menu</a>";
?>
