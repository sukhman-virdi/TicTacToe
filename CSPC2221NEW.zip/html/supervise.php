<?php
$servername = "localhost";
$username   = "root";
$password   = "root";
$database   = "tictactoe";
 
// Create connection
$conn = new mysqli($servername, $username, $password, $database);
 
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} else {
	echo "<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'>";
	echo "<div class='container mt-4'>";
	echo "Connection Successful! <br>";
}
 
$query = "SELECT tm.TournamentID, tm.Name, tm.Difficulty, pm.PrizeMoney, tm.StartDate, tm.ManagerID, tm.SupervisorID
          FROM Tournament_Managed tm
          JOIN PrizeMoney pm ON tm.Difficulty = pm.Difficulty
          ORDER BY tm.StartDate";
$result = $conn->query($query);
 
echo "<h2>All Tournaments</h2>";
 
if ($result->num_rows > 0) {
	echo "<table class='table table-bordered table-striped mt-3'>";
	echo "<tr><th>TournamentID</th><th>Name</th><th>Difficulty</th><th>PrizeMoney</th><th>StartDate</th><th>ManagerID</th><th>SupervisorID</th></tr>";
	while ($row = $result->fetch_assoc()) {
		echo "<tr>
			<td>" . $row["TournamentID"] . "</td>
			<td>" . $row["Name"] . "</td>
			<td>" . $row["Difficulty"] . "</td>
			<td>$" . $row["PrizeMoney"] . "</td>
			<td>" . $row["StartDate"] . "</td>
			<td>" . $row["ManagerID"] . "</td>
			<td>" . $row["SupervisorID"] . "</td>
		</tr>";
	}
	echo "</table>";
} else {
	echo "No tournaments found.";
}

$query = "SELECT tm.ManagerID, gu.Username, gu.Email, tm.Tournaments_Organized
          FROM TournamentManager tm
          JOIN GameUser gu ON tm.ManagerID = gu.UserID
          ORDER BY tm.Tournaments_Organized DESC";
$result = $conn->query($query);
 
echo "<h2>All Tournament Managers</h2>";
 
if ($result->num_rows > 0) {
	echo "<table class='table table-bordered table-striped mt-3'>";
	echo "<tr><th>ManagerID</th><th>Username</th><th>Email</th><th>Tournaments Organized</th></tr>";
	while ($row = $result->fetch_assoc()) {
		echo "<tr>
			<td>" . $row["ManagerID"] . "</td>
			<td>" . $row["Username"] . "</td>
			<td>" . $row["Email"] . "</td>
			<td>" . $row["Tournaments_Organized"] . "</td>
		</tr>";
	}
	echo "</table>";
} else {
	echo "No tournament managers found.";
}

// --- Aggregation Query 2: COUNT total matches per tournament ---
echo "<br><h2>Aggregation Query - Total Matches per Tournament</h2>";
echo "<b>Query: </b> SELECT Tournament, COUNT(MatchID) FROM Match_Contained GROUP BY TournamentID <br><br>";
 
$query2 = "SELECT tm.Name AS Tournament, COUNT(mc.MatchID) AS TotalMatches
           FROM Match_Contained mc
           JOIN Tournament_Managed tm ON mc.TournamentID = tm.TournamentID
           GROUP BY mc.TournamentID, tm.Name";
 
$result2 = $conn->query($query2);
 
if ($result2->num_rows > 0) {
	echo "<table class='table table-bordered table-striped mt-3'>";
	echo "<tr><th>Tournament</th><th>Total Matches</th></tr>";
	while ($row = $result2->fetch_assoc()) {
		echo "<tr>
			<td>" . $row["Tournament"] . "</td>
			<td>" . $row["TotalMatches"] . "</td>
		</tr>";
	}
	echo "</table>";
} else {
	echo "0 results";
}

$query = "SELECT mc.MatchID, mc.Match_Date, mc.Match_Time,
                 u1.Username AS Player1, u2.Username AS Player2,
                 u3.Username AS Winner, tm.Name AS Tournament
          FROM Match_Contained mc
          JOIN Plays_inMatch pm ON mc.MatchID = pm.MatchID
          JOIN GameUser u1 ON pm.Player1_ID = u1.UserID
          JOIN GameUser u2 ON pm.Player2_ID = u2.UserID
          LEFT JOIN GameUser u3 ON mc.Winner_ID = u3.UserID
          JOIN Tournament_Managed tm ON mc.TournamentID = tm.TournamentID
          ORDER BY mc.Match_Date";
$result = $conn->query($query);
 
echo "<h2>All Matches</h2>";
 
if ($result->num_rows > 0) {
	echo "<table class='table table-bordered table-striped mt-3'>";
	echo "<tr><th>MatchID</th><th>Date</th><th>Time</th><th>Tournament</th><th>Player 1</th><th>Player 2</th><th>Winner</th></tr>";
	while ($row = $result->fetch_assoc()) {
		echo "<tr>
			<td>" . $row["MatchID"] . "</td>
			<td>" . $row["Match_Date"] . "</td>
			<td>" . $row["Match_Time"] . "</td>
			<td>" . $row["Tournament"] . "</td>
			<td>" . $row["Player1"] . "</td>
			<td>" . $row["Player2"] . "</td>
			<td>" . ($row["Winner"] ?? "No winner yet") . "</td>
		</tr>";
	}
	echo "</table>";
} else {
	echo "No matches found.";
}

$query = "SELECT Difficulty, PrizeMoney FROM PrizeMoney ORDER BY Difficulty";
$result = $conn->query($query);
 
echo "<h2>All Prize Money Levels</h2>";
 
if ($result->num_rows > 0) {
	echo "<table class='table table-bordered table-striped mt-3'>";
	echo "<tr><th>Difficulty Level</th><th>Prize Money ($)</th></tr>";
	while ($row = $result->fetch_assoc()) {
		echo "<tr>
			<td>" . $row["Difficulty"] . "</td>
			<td>$" . $row["PrizeMoney"] . "</td>
		</tr>";
	}
	echo "</table>";
} else {
	echo "No prize money records found.";
}


$query = "SELECT gu.UserID, gu.Username
          FROM GameUser gu
          JOIN Player p ON gu.UserID = p.PlayerID
          WHERE NOT EXISTS (
               SELECT tm.TournamentID
               FROM Tournament_Managed tm
               WHERE NOT EXISTS (
                    SELECT j.TournamentID
                    FROM Joins j
                    WHERE j.PlayerID = p.PlayerID
                    AND j.TournamentID = tm.TournamentID
               )
          )";
 
echo "<h2>Division Query Result</h2>";
echo "<b>Query: </b> Find all players who have joined every tournament <br><br>";
 
$result = $conn->query($query);
 
if ($result->num_rows > 0) {
	echo "<table class='table table-bordered table-striped mt-3'>";
	echo "<tr><th>UserID</th><th>Username</th></tr>";
	while ($row = $result->fetch_assoc()) {
		echo "<tr>
			<td>" . $row["UserID"] . "</td>
			<td>" . $row["Username"] . "</td>
		</tr>";
	}
	echo "</table>";
} else {
	echo "No players have joined all tournaments.";
}

$query = "SELECT gu.Username, tm.Name AS Tournament, j.JoinDate
          FROM Joins j
          JOIN GameUser gu ON j.PlayerID = gu.UserID
          JOIN Tournament_Managed tm ON j.TournamentID = tm.TournamentID
          ORDER BY j.JoinDate DESC";
$result = $conn->query($query);
 
echo "<h2>All Tournament Joins</h2>";
 
if ($result->num_rows > 0) {
	echo "<table class='table table-bordered table-striped mt-3'>";
	echo "<tr><th>Username</th><th>Tournament</th><th>Join Date</th></tr>";
	while ($row = $result->fetch_assoc()) {
		echo "<tr>
			<td>" . $row["Username"] . "</td>
			<td>" . $row["Tournament"] . "</td>
			<td>" . $row["JoinDate"] . "</td>
		</tr>";
	}
	echo "</table>";
} else {
	echo "No join records found.";
}


$conn->close();
 
echo "</div><br><a class='btn btn-secondary' href='admin.html'>Main Menu</a>";
?>
