<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$servername = "localhost";
$username   = "root";
$password   = "root";
$database   = "tictactoe";
 
// Getting values
$AchievementID = $_POST['AchievementID'];
$Title = $_POST['Title'];
$Description = $_POST['Description'];
 
// Input validation
if (empty($AchievementID) || !is_numeric($AchievementID)) {
	echo "Error: Please enter a valid Achievement ID. <br>";
	echo "<a class='btn btn-secondary mt-2' href='edit.php'>Go Back</a>";
	exit;
}
 
if (empty($Title)) {
	echo "Error: Title must be a valid text. <br>";
	echo "<a class='btn btn-secondary mt-2' href='edit.php'>Go Back</a>";
	exit;
}
if (empty($Description)) {
	echo "Error: Description must be a valid text. <br>";
	echo "<a class='btn btn-secondary mt-2' href='edit.php'>Go Back</a>";
	exit;
}
 
// Create connection
$conn = new mysqli($servername, $username, $password, $database);
 
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} else {
	echo "<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'>";
	echo "<div class='container mt-4'>";
	echo "Connection Successful! <br>";
}
 
// Check Achievement exists and show before
$checkQuery  = "SELECT AchievementID, Title, Description FROM Achievement WHERE AchievementID = '$AchievementID'";
$checkResult = $conn->query($checkQuery);
 
if ($checkResult->num_rows == 0) {
	echo "Error: No Achievement found with AchievementID: $AchievementID <br>";
	echo "<a class='btn btn-secondary mt-2' href='edit.php'>Go Back</a>";
	$conn->close();
	exit;
}
 
$Achievement = $checkResult->fetch_assoc();
 
// Construct and execute the update query
$query = "UPDATE Achievement SET Title = '$Title', Description = '$Description' WHERE AchievementID = '$AchievementID'";
 
if ($conn->query($query) === TRUE) {
	$adminID = $_SESSION['AdminID'];
    $logQuery = "INSERT INTO Edits (AdminID, AchievementID, EditDate)
                 VALUES ('$adminID', '$AchievementID', CURRENT_DATE)";
    $conn->query($logQuery);

	echo "Title updated successfully! <br>";
	echo "Description updated successfully! <br><br>";
 
	// Show before and after as table
	echo "<table class='table table-bordered table-striped mt-3'>";
	echo "<tr><th>AchievementID</th><th>Title Before</th><th>Title After</th><th>Description Before</th><th>Description After</th></tr>";
	echo "<tr>
		<td>" . $Achievement["AchievementID"] . "</td>
		<td>" . $Achievement["Title"] . "</td>
		<td>" . $Title . "</td>
		<td>" . $Achievement["Description"] . "</td>
		<td>" . $Description . "</td>
	</tr>";
	echo "</table>";
} else {
	echo "Error: " . $conn->error;
}
 
$conn->close();
 
echo "</div><br><a class='btn btn-secondary' href='edit.php'>Update Another Achievement</a> | <a href='admin.html'>Main Menu</a>";
?>
