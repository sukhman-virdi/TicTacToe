<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username   = "root";
$password   = "root";
$database   = "tictactoe";
 
// Getting values
$AchievementID   = $_POST['AchievementID'];
$Title = $_POST['Title'];
$Description = $_POST['Description'];
 
// Input validation
if (empty($AchievementID) || empty($Title) || empty($Description)) {
	echo "Error: All fields are required. <br>";
	echo "<a class='btn btn-secondary mt-2' href='edit.php'>Go Back</a>";
	exit;
}
 
// Create connection
$conn = new mysqli($servername, $username, $password, $database);
 
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}else{
    echo "<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'>";
	echo "<div class='container mt-4'>";
	echo "Connection Successful! <br>";
}
 
// Construct the query
$query = "INSERT INTO Achievement VALUES('$AchievementID', '$Title', '$Description')";
 
// Execute the query
if ($conn->query($query) === TRUE) {
    $adminID = $_SESSION['AdminID'];
    $logQuery = "INSERT INTO Edits (AdminID, AchievementID, EditDate)
                 VALUES ('$adminID', '$AchievementID', CURRENT_DATE)";
    $conn->query($logQuery);
	echo "New user inserted successfully! <br><br>";
	// Show inserted record as table
	$result = $conn->query("SELECT * FROM Achievement WHERE AchievementID = '$AchievementID'");
	echo "<table class='table table-bordered table-striped mt-3'>";
	echo "<tr><th>AchievementID</th><th>Title</th><th>Description</th></tr>";
	while ($row = $result->fetch_assoc()) {
		echo "<tr>
			<td>" . $row["AchievementID"] . "</td>
			<td>" . $row["Title"] . "</td>
			<td>" . $row["Description"] . "</td>
		</tr>";
	}
	echo "</table>";
} else {
	echo "Error: " . $conn->error;
}

$conn->close();
echo "</div><br><a class='btn btn-secondary' href='edit.php'>Add Another User</a> | <a href='admin.html'>Main Menu</a>";
?>
