<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$servername = "localhost";
$username   = "root";
$password   = "root";
$database   = "tictactoe";
 
// Getting values
$AchievementID = $_POST['AchievementID'];
 
// Input validation
if (empty($AchievementID) || !is_numeric($AchievementID)) {
	echo "Error: Please enter a valid Achievement ID. <br>";
	echo "<a class='btn btn-secondary mt-2' href='edit.php'>Go Back</a>";
	exit;
}
 
// Create connection
$conn = new mysqli($servername, $username, $password, $database);
 
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} else {
	echo "<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'>";
	echo "<div class='container mt-4'>";
	echo "Connection Successful! <br>";
}
 
// Check achievement exists
$checkQuery  = "SELECT AchievementID, Title, Description FROM Achievement WHERE AchievementID = '$AchievementID'";
$checkResult = $conn->query($checkQuery);
 
if ($checkResult->num_rows == 0) {
	echo "Error: No archievement found with AchievementID: $AchievementID <br>";
	echo "<a class='btn btn-secondary mt-2' href='edit.php'>Go Back</a>";
	$conn->close();
	exit;
}
 
// Show what will be deleted
$achievement = $checkResult->fetch_assoc();
echo "<h2>Deleting Achievement</h2>";
echo "<table class='table table-bordered table-striped mt-3'>";
echo "<tr><th>AchievementID</th><th>Title</th><th>Description</th></tr>";
echo "<tr>
	<td>" . $achievement["AchievementID"] . "</td>
	<td>" . $achievement["Title"] . "</td>
	<td>" . $achievement["Description"] . "</td>
</tr>";
echo "</table><br>";
 
// Construct and execute the query
$query = "DELETE FROM Achievement WHERE AchievementID = '$AchievementID'";
 
if ($conn->query($query) === TRUE) {
	$adminID = $_SESSION['AdminID'];
    $logQuery = "INSERT INTO Edits (AdminID, AchievementID, EditDate)
                 VALUES ('$adminID', '$AchievementID', CURRENT_DATE)";
    $conn->query($logQuery);
	echo "Achievement '$AchievementID' and all related records deleted successfully!";
} else {
	echo "Error: " . $conn->error;
}
 
$conn->close();
 
echo "</div><br><a class='btn btn-secondary' href='edit.php'>Delete Another User</a> | <a href='admin.html'>Main Menu</a>";
?>
